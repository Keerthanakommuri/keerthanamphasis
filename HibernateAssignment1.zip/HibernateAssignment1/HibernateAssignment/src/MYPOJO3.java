

public class MYPOJO3 {

	String empno,name, phoneno,address;
	
	
	@Override
	public String toString() {
		return "MYPOJO3 [empno=" + empno + ", name=" + name + ", phoneno=" + phoneno + ", address=" + address + "]";
	}

	public String getEmpno() {
		return empno;
	}

	public void setEmpno(String empno) {
		this.empno = empno;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	
}
