package com.dineshonjava.service;

import java.util.List;

import com.dineshonjava.model.Bank;

 
public interface BankService {
	
	public void addEmployee(Bank employee);

	public List<Bank> listEmployeess();
	
	public Bank getEmployee(String name);
	
	public void deleteEmployee(Bank employee);
}
