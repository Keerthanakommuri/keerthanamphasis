package com.dineshonjava.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.dineshonjava.dao.BankDao;
import com.dineshonjava.model.Bank;

 
@Service("employeeService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public abstract class BankServiceImpl implements BankService {

	@Autowired
	private BankDao employeeDao;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	// So a transaction with this isolation reads uncommitted data of other concurrent transactions
	public void addEmployee(Bank employee) {
		employeeDao.addEmployee(employee);
	}
	
	public List<Bank> listEmployeess() {
		return employeeDao.listEmployeess();
	}

	public Bank getEmployee(String name) {
		return employeeDao.getEmployee(name);
	}
	
	public void deleteEmployee(Bank employee) {
		employeeDao.deleteEmployee(employee);
	}

}
