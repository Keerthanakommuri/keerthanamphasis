package com.dineshonjava.dao;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.dineshonjava.model.Bank;

 
@Repository("employeeDao")
public abstract class BankDaoImpl implements BankDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addEmployee(Bank employee) {
		sessionFactory.getCurrentSession().saveOrUpdate(employee);
	}

//	@SuppressWarnings("unchecked")
	public List<Bank> listEmployeess() 
	{
		return (List<Bank>) sessionFactory.openSession().createCriteria(Bank.class).list();
	}

	public Bank getEmployee(String name) {
		return (Bank) sessionFactory.getCurrentSession().get(Bank.class, name);
	}

	public void deleteEmployee(Bank employee) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM Bank2 WHERE empname = "+employee.getName()).executeUpdate();
	}

}
