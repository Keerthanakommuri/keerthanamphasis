package com.dineshonjava.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

 
@Entity
@Table(name="Bank2")
public class Bank implements Serializable{

	 
	@Column(name="name")
	private String Name;
	
	@Column(name="address")
	private String Address;
	
	@Column(name="phoneno")
	private String Phoneno;
	
	@Column(name="Email")
	private String Email;
	
	@Column(name="companyname")
	private String Companyname;
	
	@Column(name="Age")
	private String Age;
	
	@Column(name="Openingbalance")
	private String Openingbalance;

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getPhoneno() {
		return Phoneno;
	}

	public void setPhoneno(String phoneno) {
		Phoneno = phoneno;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}

	public String getCompanyname() {
		return Companyname;
	}

	public void setCompanyname(String companyname) {
		Companyname = companyname;
	}

	public String getAge() {
		return Age;
	}

	public void setAge(String age) {
		Age = age;
	}

	public String getOpeningbalance() {
		return Openingbalance;
	}

	public void setOpeningbalance(String openingbalance) {
		Openingbalance = openingbalance;
	}



}