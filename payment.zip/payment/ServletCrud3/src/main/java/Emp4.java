public class Emp4 {
private int id;
private String name,email,date,card,number,message;

public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getDoj() {
	return date;
}
public void setDoj(String doj) {
	this.date = date;
}
public String getCard() {
	return card;
}
public void setCard(String card) {
	this.card = card;
}
public String getNumber() {
	return number;
}
public void setNumber(String number) {
	this.number = number;
}
public String getMessage() {
	return message;
}
public void setMessage(String message) {
	this.message = message;
}
}
