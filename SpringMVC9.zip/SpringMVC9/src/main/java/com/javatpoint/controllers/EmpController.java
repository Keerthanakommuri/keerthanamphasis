package com.javatpoint.controllers;

import java.util.ArrayList;
import java.util.List;
import java.sql.*;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.javatpoint.beans.Emp;

@Controller
public class EmpController {
Emp emp=new Emp();

	@RequestMapping("/empform1")
	public ModelAndView showform(){
		return new ModelAndView("empform","command",new Emp());
	}
	@RequestMapping("/updateemp")
	public ModelAndView updateform(){
		return new ModelAndView("updateform","command",new Emp());
	}
	@RequestMapping("/deleteemp")
	public ModelAndView deleteform(){
		return new ModelAndView("deleteform","command",new Emp());
	}
	@RequestMapping("/viewemp")
    public ModelAndView viewform(){
        return new ModelAndView("viewemp","command",new Emp());
    }
	@RequestMapping("/loginemp")
    public ModelAndView loginform(){
        return new ModelAndView("loginemp","command",new Emp());
    }
	
	
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute("emp") Emp emp)
	{
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("insert into  reg values(?,?,?,?,?)");
			System.out.println(emp.getId()+" "+emp.getName()+" "+emp.getAddress()+" "+emp.getPhoneno()+" "+emp.getPassword());
			st.setString(1,emp.getId());
			st.setString(2,emp.getName());
			st.setString(3,emp.getAddress());
			st.setString(4,emp.getPhoneno());
			st.setString(5,emp.getPassword());
			st.execute();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("redirect:/loginemp");
	}
	
	@RequestMapping(value="/update",method = RequestMethod.POST)
	public ModelAndView updateemp(@ModelAttribute("emp") Emp emp){
				
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("update reg set name=?,address=?,phoneno=?,password=? where id=?");
		emp.setId(emp.getId()); 
		System.out.println(emp.getId()+" "+emp.getName()+" "+emp.getAddress()+" "+emp.getPhoneno()+" "+emp.getPassword());	
		st.setString(1,emp.getName());
			 st.setString(2,emp.getAddress());
			 st.setString(3,emp.getPhoneno());
			 st.setString(4,emp.getPassword());
			 st.setString(5,emp.getId());
			 
			
			st.execute();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("viewemp");
	}
	
	@RequestMapping("/delete")
	public ModelAndView update(@ModelAttribute("emp") Emp emp)
	{
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("delete reg where id=?");
			System.out.println(emp.getId());
		    st.setString(1,emp.getId());
			st.execute();
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("viewemp");
	
	}

	@RequestMapping(value="/login",method = RequestMethod.POST)
	public ModelAndView loginemp(@ModelAttribute("emp") Emp emp){
				
		try
		{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
		PreparedStatement st=con.prepareStatement("select * from reg where name=? and password=?");
			
			st.setString(1,emp.getName());
			st.setString(2,emp.getPassword());	
			ResultSet rs=st.executeQuery();
			int x=0;
			while(rs.next())
			{
				x=1;//when there is data
			}
			if(x==1)
			{
				
				String message = "Success";  
		        return new ModelAndView(message); 
			}
			else
			{
				return new ModelAndView("redirect:/loginemp");
			}
		}
		catch(Exception ae)
		{
			ae.printStackTrace();
		}
		return new ModelAndView("redirect:/loginemp");
	}

		
	}
	
