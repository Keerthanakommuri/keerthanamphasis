import java.util.*;
import java.sql.*;

public class EmpDao2 {

 public static Connection getConnection(){
  Connection con=null;
  try{
   Class.forName("oracle.jdbc.driver.OracleDriver");
   con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
  }catch(Exception e){System.out.println(e);}
  return con;
 }
 public static int save(Emp2 e){
  int status=0;
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("insert into room(id,name,email,doj,room,no,message) values (crud.nextval,?,?,?,?,?,?)");
   ps.setString(1,e.getName());
   ps.setString(2,e.getEmail());
   ps.setString(3,e.getDoj());
   ps.setString(4,e.getRoom());
   ps.setString(5,e.getNo());
   ps.setString(6,e.getMessage());
   status=ps.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int update(Emp2 e){
  int status=0;
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("update room set name=?,email=?,doj=?,room=?,no=?,message=? where id=?");
   ps.setString(1,e.getName());
   ps.setString(2,e.getEmail());
   ps.setString(3,e.getDoj());
   ps.setString(4,e.getRoom());
   ps.setString(5,e.getNo());
   ps.setString(6,e.getMessage());
   ps.setInt(7,e.getId());
   
   status=ps.executeUpdate();
   
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return status;
 }
 public static int delete(int id){
  int status=0;
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("delete from room where id=?");
   ps.setInt(1,id);
   status=ps.executeUpdate();
   
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return status;
 }
 public static Emp2 getEmployeeById(int id){
  Emp2 e=new Emp2();
  
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from room where id=?");
   ps.setInt(1,id);
   ResultSet rs=ps.executeQuery();
   if(rs.next()){
    e.setId(rs.getInt(1));
    e.setName(rs.getString(2));
    e.setEmail(rs.getString(3));
    e.setDoj(rs.getString(4));
    e.setRoom(rs.getString(5));
    e.setNo(rs.getString(6));
    e.setMessage(rs.getString(7));
   
   }
   con.close();
  }catch(Exception ex){ex.printStackTrace();}
  
  return e;
 }
 public static List<Emp2> getAllEmployees(){
  List<Emp2> list=new ArrayList<Emp2>();
  
  try{
   Connection con=EmpDao2.getConnection();
   PreparedStatement ps=con.prepareStatement("select * from room");
   ResultSet rs=ps.executeQuery();
   while(rs.next()){
    Emp2 e=new Emp2();
    e.setId(rs.getInt(1));
    e.setName(rs.getString(2));
    e.setEmail(rs.getString(3));
    e.setDoj(rs.getString(4));
    e.setRoom(rs.getString(5));
    e.setNo(rs.getString(6));
    e.setMessage(rs.getString(7));
   
    list.add(e);
   }
   con.close();
  }catch(Exception e){e.printStackTrace();}
  
  return list;
 }
}
